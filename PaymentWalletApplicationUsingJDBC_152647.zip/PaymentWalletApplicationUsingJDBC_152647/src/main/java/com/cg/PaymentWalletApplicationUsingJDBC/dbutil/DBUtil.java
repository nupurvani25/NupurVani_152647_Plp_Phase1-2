package com.cg.PaymentWalletApplicationUsingJDBC.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBUtil  {
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Setup the connection with the DB
		Connection connect=null;
		try {
			//con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wrox?user=xxx&password=xxxxxxxx");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/nupur?user=root&password=Capgemini123");
			if(connect==null)
			{
				System.out.println("hi nupur");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(connect);
		// TODO Auto-generated method stub
		return connect;
	}
	
	}


