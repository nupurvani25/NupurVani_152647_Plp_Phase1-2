package com.cg.PaymentWalletApplicationUsingJDBC.exception;

public class InsufficientBalanceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
