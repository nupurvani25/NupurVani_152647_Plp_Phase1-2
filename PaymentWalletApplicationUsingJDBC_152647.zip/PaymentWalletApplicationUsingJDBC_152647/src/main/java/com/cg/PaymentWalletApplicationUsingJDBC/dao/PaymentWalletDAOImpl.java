package com.cg.PaymentWalletApplicationUsingJDBC.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;

import com.cg.PaymentWalletApplicationUsingJDBC.bean.Customer;
import com.cg.PaymentWalletApplicationUsingJDBC.bean.Wallet;
import com.cg.PaymentWalletApplicationUsingJDBC.dbutil.DBUtil;


public class PaymentWalletDAOImpl implements IPaymentWalletDAO {
	static HashMap<String, Wallet> map = new HashMap<String, Wallet>();
	static Wallet wallet;

	int transactionId;
	static int customerAccountNo;
	public static Connection connection=DBUtil.getConnection();

	public boolean addWalletDetails(Wallet wallet) {
		Customer customer = wallet.getCustomerDetails();
		int n1 = 0;
		int n2 = 0;
		try {
			String insertQuery1 ="insert into customer values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt1 = connection.prepareStatement(insertQuery1);
			pstmt1.setString(1, customer.getAadharNo());
			pstmt1.setString(2, customer.getCustomerName());
			pstmt1.setInt(3, customer.getAge());
			pstmt1.setString(4, customer.getGender());
			pstmt1.setString(5, customer.getCustomerMobileNo());
			pstmt1.setString(6, customer.getCustomerEmail());
			pstmt1.setString(7, customer.getUserName());
			pstmt1.setString(8, customer.getUserPassword());
			pstmt1.setInt(9, wallet.getCustomerAccountNo());

			n1 = pstmt1.executeUpdate();

			String insertQuery2 = "insert into wallet values(?,?,?)";
			PreparedStatement pstmt2 = connection.prepareStatement(insertQuery2);
			
			pstmt2.setFloat(1, wallet.getCustomerBalance());
			pstmt2.setInt(2, wallet.getCustomerAccountNo());
			pstmt2.setString(3, wallet.getCustomerAccountDate().toString());

			n2 = pstmt2.executeUpdate();

			String insertQuery3 = "insert INTO Trans values(?,?)";
			PreparedStatement pstmt3 = connection.prepareStatement(insertQuery3);
			pstmt3.setString(1, "Transactions");
			pstmt3.setInt(2, wallet.getCustomerAccountNo());

		}

		catch (SQLException e) {
			e.printStackTrace();
		}

		if (n1 == 1 && n2 == 1) {
			return true;
		} else {
			return false;
		}

	}

	public float showBalance() {
		// TODO Auto-generated method stub
		try {
			Statement statement = connection.createStatement();
			String selectQuery = "select wallet.customerBalance from wallet where customerAccountNo='" + customerAccountNo
					+ "' ";
			ResultSet resultset = statement.executeQuery(selectQuery);
			while (resultset.next()) {
				float bal = resultset.getFloat(1);
				return bal;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;

	}

	public boolean depositAmount(float amount) {
		// TODO Auto-generated method stub
		String updateQuery = "update wallet set customerBalance=customerBalance+? where customerAccountNo=?";
		try {
			transactionId = (int) ((Math.random() * 123) + 999);
			java.sql.PreparedStatement pstmt4 = connection.prepareStatement(updateQuery);
			pstmt4.setFloat(1, amount);
			pstmt4.setInt(2, customerAccountNo);
			pstmt4.executeUpdate();

			String deposit = transactionId + "  Amount of " + amount + " is deposited";
			transactionAdd(deposit);

		} catch (SQLException e) {
			System.err.println("Amount not deposited...!!!");
			return false;
		}
		return true;

	}

	private void transactionAdd(String deposit) {
		// TODO Auto-generated method stub
		String insertQueryTransaction = "insert into Trans values(?,?) ";
		PreparedStatement pstmt5;
		try {

			pstmt5 = connection.prepareStatement(insertQueryTransaction);
			pstmt5.setString(1, "\n" + deposit);
			pstmt5.setInt(2, customerAccountNo);
			pstmt5.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Transaction not added...!!!");
		}

	}

	public boolean withdrawAmount(float amount) {
		// TODO Auto-generated method stub
		transactionId = (int) ((Math.random() * 123) + 999);
		float bal = 0;
		try {
			Statement statement = connection.createStatement();
			String selectQuery = "select customerBalance from wallet where customerAccountNo='" + customerAccountNo
					+ " ' ";
			ResultSet resultset = statement.executeQuery(selectQuery);
			while (resultset.next()) {
				bal = resultset.getFloat(1);
			}
		} catch (SQLException e) {
			System.err.println("Amount not withdrawn....!!!!");

		}
		if (bal >= amount) {
			try {
				String updateQuery = "update wallet set customerBalance=customerBalance-? where customerAccountNo=?";
				PreparedStatement pstat = connection.prepareStatement(updateQuery);
				pstat.setFloat(1, amount);
				pstat.setInt(2, customerAccountNo);
				pstat.executeUpdate();

				String withdrawl = transactionId + "  Amount of " + amount + " is withdrawn.....!!!";
				transactionAdd(withdrawl);

				return true;
			} catch (SQLException e) {
				System.err.println("Amount not withdrawn....!!!");

			}

		}
		return false;

	}

	public boolean loginAccount(String uName, String uPassword) {
		// TODO Auto-generated method stub
		try {
			Statement statement = connection.createStatement();
			String selectQuery = "select customer.userName,customer.userPassword,customer.customerAccountNo from customer,wallet where customer.customerAccountNo=wallet.customerAccountNo";

			ResultSet rs = statement.executeQuery(selectQuery);
			while (rs.next()) {
				String userName = rs.getString(1);
				String userPass = rs.getString(2);
				customerAccountNo = rs.getInt(3);
				if (userName.equals(uName) && userPass.equals(uPassword)) {

					return true;
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	public boolean fundTransfer(int accNo, float amount) {
		// TODO Auto-generated method stub
		float bal = 0;
		transactionId = (int) ((Math.random() * 123) + 999);
		try {
			Statement stat = connection.createStatement();
			String selectQuery = "select customerBalance from wallet where customerAccountNo='" + customerAccountNo
					+ " ' ";
			ResultSet rs = stat.executeQuery(selectQuery);
			while (rs.next()) {
				bal = rs.getFloat(1);
			}
		} catch (SQLException e) {
			System.err.println("Fund Not Transferred...!!");

		}

		if (bal >= amount) {
			try {
				String updateQuery1 = "update wallet set customerBalance=customerBalance+? where customerAccountNo=?";

				java.sql.PreparedStatement pstat1 = connection.prepareStatement(updateQuery1);
				pstat1.setFloat(1, amount);
				pstat1.setInt(2, accNo);
				pstat1.executeUpdate();

				String updateQuery2 = "update wallet set customerBalance=customerBalance-? where customerAccountNo=?";

				PreparedStatement pstat2 = connection.prepareStatement(updateQuery2);
				pstat2.setFloat(1, amount);
				pstat2.setInt(2, customerAccountNo);
				pstat2.executeUpdate();

				String transfer = transactionId + "  Amount of " + amount + " is transferred to " + accNo;
				transactionAdd(transfer);

				return true;

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return false;

	}

	public void printTransaction() {
		// TODO Auto-generated method stub

		try {
			Statement stat = connection.createStatement();
			String selectQuery = "select transactions from Trans where customerAccountNo='" + customerAccountNo + "' ";
			ResultSet rs = stat.executeQuery(selectQuery);
			while (rs.next()) {

				System.out.println(rs.getString(1));
			}
		} catch (SQLException e) {
			System.err.println("Passbook not updated...!!!");
			e.printStackTrace();
		}

	}


}
