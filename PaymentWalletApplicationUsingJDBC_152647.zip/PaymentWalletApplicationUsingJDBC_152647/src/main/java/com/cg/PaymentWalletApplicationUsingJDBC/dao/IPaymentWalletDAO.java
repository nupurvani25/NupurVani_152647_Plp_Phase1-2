package com.cg.PaymentWalletApplicationUsingJDBC.dao;

import com.cg.PaymentWalletApplicationUsingJDBC.bean.Wallet;


public interface IPaymentWalletDAO {
	public float showBalance();
	public boolean depositAmount(float amount);
	public boolean withdrawAmount(float amount);
	public boolean loginAccount(String uName,String uPassword);
	public boolean fundTransfer(int accNo,float amount);
	public void printTransaction();
	public boolean addWalletDetails(Wallet wallet);
}
