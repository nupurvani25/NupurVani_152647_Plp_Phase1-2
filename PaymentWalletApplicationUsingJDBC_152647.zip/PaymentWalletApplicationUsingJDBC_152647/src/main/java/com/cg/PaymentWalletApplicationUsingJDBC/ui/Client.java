package com.cg.PaymentWalletApplicationUsingJDBC.ui;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.PaymentWalletApplicationUsingJDBC.bean.Customer;
import com.cg.PaymentWalletApplicationUsingJDBC.bean.Wallet;
import com.cg.PaymentWalletApplicationUsingJDBC.exception.InsufficientBalanceException;
import com.cg.PaymentWalletApplicationUsingJDBC.exception.InvalidInputException;
import com.cg.PaymentWalletApplicationUsingJDBC.service.PaymentWalletServiceImpl;
import com.cg.PaymentWalletApplicationUsingJDBC.service.PaymentWalletValidation;

import java.util.InputMismatchException;
import java.util.Iterator;

public class Client {

	public static void main(String[] args) {

		int choice = 0;
		do {
			int choice1 = 0;
			Scanner scanner = new Scanner(System.in);
			printDetails();

			boolean b = false;
			do {
				try {
					choice = scanner.nextInt();
					b = true;
				} catch (InputMismatchException e) {
					System.out.println("Invalid Choice");
					System.out.println("Please Try Again.....");
					System.out.println("Enter Your Choice");
				}

				scanner.nextLine();
			} while (b == false);

			switch (choice) {
			case 1:
				createAccount();
				break;

			case 2:

				boolean login = loginAccount();
				if (login) {
					do {

						System.out.println("________________________");
						System.out.println("..........Menu..........\n");
						System.out.println("1. SHOW BALANCE\t\t\t\t 4. FUND TRANSFER");
						System.out.println("2. DEPOSIT AMOUNT\t\t\t 5. PRINT TRANSACTION");
						System.out.println("3. WITHDRAW AMOUNT \t\t\t 6. SIGN OUT");

						boolean b1 = false;
						do {
							try {
								System.out.println("\nHello User......\nEnter Your Choice");
								choice1 = scanner.nextInt();
								b1 = true;
							} catch (InputMismatchException e) {
								System.err.println("Invalid Choice");
								System.out.println("Please Try Again.....");
							}

							scanner.nextLine();
						} while (b1 == false);

						switch (choice1) {

						case 1:
							showBalance();
							break;

						case 2:
							depositAmount();
							break;

						case 3:
							withdrawAmount();
							break;

						case 4:
							fundTransfer();
							break;

						case 5:
							printTransaction();
							break;
						case 6:
							System.out.println("THANKS FOR USING OUR SERVICE.... VISIT AGAIN...:)");

							break;
						default:
							System.out.println("INVALID INPUT.... PLEASE TRY AGAIN....");
							break;

						}

					} while (choice1 != 6);

				}

				else {
					System.out.println("Invalid Login Details..Try Again..");
				}
				break;

			default:
				System.out.println("Invalid Choice..Please Try Again..");
				break;

			}
		} while (choice != 3);

	}

	public static void createAccount() {

		Wallet wallet = new Wallet();
		Customer account = new Customer();

		PaymentWalletServiceImpl service = new PaymentWalletServiceImpl();
		PaymentWalletValidation validate = new PaymentWalletValidation();

		Scanner scan = new Scanner(System.in);
		
		// Aadhar_Number
		System.out.println("Enter Customer 12 digit Aadhar Number");
		String aadharNo = scan.nextLine();
		boolean isValidAadharNo = validate.validateAadharNo(aadharNo);
		while (!isValidAadharNo) {
			System.out.println("Invalid Aadhar Number..\nTry again...");
			System.out.println("Enter Customer 12 digit Aadhar Number");
			aadharNo = scan.nextLine();
			isValidAadharNo = validate.validateAadharNo(aadharNo);
		}

		// CustomerName
		System.out.println("Enter Customer Name");
		String custName = scan.nextLine();
		boolean isValidCustName = validate.validateCustomerName(custName);
		while (!isValidCustName) {
			System.out.println("Customer Name Should contain only albhabets\nTry again...");
			System.out.println("Enter Customer Name");
			custName = scan.nextLine();
			isValidCustName = validate.validateCustomerName(custName);
		}


		// CustomerAge
		boolean b = false;
		int age = 0;
		do {

			try {
				System.out.println("Enter Customer Age");

				age = scan.nextInt();
				b = true;
			} catch (InputMismatchException e) {
				System.out.println("Invalid age");
				System.out.println("Please Try Again.....");
			}

			scan.nextLine();
		} while (b == false);
		
		// CustomerGender
		System.out.println("Enter Customer gender");
		String gender = scan.nextLine();
		boolean isValidGender = validate.validateGender(gender);
		while (!isValidGender) {
			System.out.println("Invalid Gender \nTry again...");
			System.out.println("Enter Customer gender");
			gender = scan.nextLine();
			isValidGender = validate.validateGender(gender);

		}
		

		// CustomerMobileNumber
		System.out.println("Enter Customer Mobile Number");
		String custMobileNo = scan.nextLine();
		boolean isValidMobileNo = validate.validateMobileNo(custMobileNo);
		while (!isValidMobileNo) {
			System.out.println("Invalid MobileNo \nTry again...");
			System.out.println("Enter Customer Mobile Number");
			custMobileNo = scan.nextLine();
			isValidMobileNo = validate.validateMobileNo(custMobileNo);
		}

		// CustomerEmailId
		System.out.println("Enter Customer EmailID");
		String custEmail = scan.nextLine();
		boolean isValidEmailId = validate.validateEmailId(custEmail);
		while (!isValidEmailId) {
			System.out.println("Invalid EmailId \nTry again...");
			System.out.println("Enter Customer EmailID");
			custEmail = scan.nextLine();
			isValidEmailId = validate.validateEmailId(custEmail);
		}

		// UserName
		System.out.println("Enter your UserName ");
		String userName = scan.nextLine();
		boolean isValidUserName = validate.validateUserName(userName);
		while (!isValidUserName) {
			System.out.println("Try Again...");
			System.out.println("Enter your UserName ");
			userName = scan.nextLine();
			isValidUserName = validate.validateUserName(userName);
		}

		// Password
		System.out.println("Enter your Password");
		String userPassword = scan.nextLine();
		boolean isValidPassword = validate.validateUserPassword(userPassword);
		while (!isValidPassword) {
			System.out.println("Password should be greater than or equal to 8 character\n Try again...");
			System.out.println("Enter your Password");
			userPassword = scan.nextLine();
			isValidPassword = validate.validateUserPassword(userPassword);
		}

	
	
		// AccountNumber
				int custAccNo = (int) (Math.random() * 123456 + 123456);


	


		// CustomerOpeningBalance
		System.out.println("Enter Opening Blanace");
		float custInitBal = scan.nextFloat();
		boolean isValidCustInitBal = validate.validateCustInitBal(custInitBal);
		while (!isValidCustInitBal) {
			System.out.println("Invalid Balance \nTry again...");
			System.out.println("Enter Opening Blanace");
			custInitBal = scan.nextFloat();
			isValidCustInitBal = validate.validateCustInitBal(custInitBal);
		}

		
		// AccountOpeningDate
		LocalDate custAccOpenDate = LocalDate.now();
		
		account.setAadharNo(aadharNo);
		account.setCustomerName(custName);
		account.setAge(age);
		account.setGender(gender);
		account.setCustomerMobileNo(custMobileNo);
		account.setCustomerEmail(custEmail);
        account.setUserName(userName);
		account.setUserPassword(userPassword);

		wallet.setCustomerAccountDate(custAccOpenDate);
		wallet.setCustomerAccountNo(custAccNo);
		wallet.setCustomerBalance(custInitBal);
		wallet.setCustomerDetails(account);

		boolean b1 = service.addWalletDetails(wallet);
		if (b1) {

			System.out.println("Account Created.. Account Number is: " + custAccNo);
			System.out.println("Your UserName is: " + userName);
			System.out.println("Your Password is :" + userPassword);

		} else {
			System.out.println("Account Not Created...!!!");
		}
	}

	public static void showBalance() {

		PaymentWalletServiceImpl service = new PaymentWalletServiceImpl();

		float balance = service.showBalance();
		System.out.println("Account Balance is: " + balance);
	}

	public static void depositAmount() {
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		PaymentWalletServiceImpl service = new PaymentWalletServiceImpl();

		System.out.println("Enter amount to deposit...");
		float amount = scan.nextFloat();
		boolean isDeposit = service.depositAmount(amount);

		if (isDeposit) {
			System.out.println("Amount Deposited in your account...!!!");
		}

	}

	public static void withdrawAmount() {
		Scanner scan = new Scanner(System.in);
		PaymentWalletServiceImpl service = new PaymentWalletServiceImpl();

		System.out.println("Enter amount to withdraw...");
		float amount = scan.nextFloat();
		boolean isDeposit = service.withdrawAmount(amount);

		if (isDeposit) {
			System.out.println("Amount Withdraw from your account...!!!");
		} else {
			try {
				throw new InsufficientBalanceException();
			} catch (InsufficientBalanceException e) {
				System.out.println(e);
			}
		}

	}

	public static boolean loginAccount() {
		Scanner scan = new Scanner(System.in);
		PaymentWalletServiceImpl service = new PaymentWalletServiceImpl();
		System.out.println("Enter Your Username");
		String uName = scan.nextLine();
		System.out.println("Enter Your Password");
		String uPassword = scan.nextLine();

		boolean b = service.loginAccount(uName, uPassword);
		if (b) {
			return true;
		} else {
			try {
				throw new InvalidInputException();
			} catch (InvalidInputException e) {
				System.out.println(e);
			}
		}
		return false;
	}

	public static void fundTransfer() {
		Scanner s = new Scanner(System.in);
		System.out.println(" Enter Account Number to transfer amount...");
		int accNo = s.nextInt();
		System.out.println("Enter Amount to Transfer...");
		float amount = s.nextFloat();
		PaymentWalletServiceImpl service = new PaymentWalletServiceImpl();
		boolean b = service.fundTransfer(accNo, amount);
		if (b) {
			System.out.println("Fund Successfully Transfer...!!!");
		} else {
			System.out.println("Enter Correct Input...!!!");
		}

	}

	public static void printTransaction() {

		PaymentWalletServiceImpl service = new PaymentWalletServiceImpl();

		service.printTransaction();

	}

	private static void printDetails() {
		// TODO Auto-generated method stub
		System.out.println("\t\t\t\t_____________________________________________________");
		System.out.println("\t\t\t\t............PAYMENT WALLET APPLICATION...............");
		System.out.println("\t\t\t\t_____________________________________________________");
		System.out.println("\t\t\t\t..                                                 ..");
		System.out.println("\t\t\t\t..            	  1.CREATE ACCOUNT                 ..");
		System.out.println("\t\t\t\t..          	  2.LOGIN                          ..");
		System.out.println("\t\t\t\t..                3.EXIT                           ..");
		System.out.println("\t\t\t\t..                                                 ..");
		System.out.println("\t\t\t\t.....................................................");
		System.out.println("\t\t\t\t.....................................................");
		System.out.println("\t\t\t\t...............Enter Your Choice.....................");

	}
}
