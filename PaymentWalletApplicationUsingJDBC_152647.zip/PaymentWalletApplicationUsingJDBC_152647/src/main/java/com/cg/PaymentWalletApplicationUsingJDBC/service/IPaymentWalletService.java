package com.cg.PaymentWalletApplicationUsingJDBC.service;

import com.cg.PaymentWalletApplicationUsingJDBC.bean.Wallet;



public interface IPaymentWalletService {
	public float showBalance();
	public boolean depositAmount(float amount);
	public boolean withdrawAmount(float amount);
	public boolean loginAccount(String uName,String uPassword);
	public boolean fundTransfer(int accNo,float amount);
	public void printTransaction();
	public boolean addWalletDetails(Wallet wallet);
}
