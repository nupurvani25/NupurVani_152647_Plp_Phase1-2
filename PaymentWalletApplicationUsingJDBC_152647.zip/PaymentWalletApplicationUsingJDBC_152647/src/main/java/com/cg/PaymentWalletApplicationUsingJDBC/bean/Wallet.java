package com.cg.PaymentWalletApplicationUsingJDBC.bean;
import java.time.LocalDate;


public class Wallet {

	private float customerBalance;
	private int customerAccountNo;
	private LocalDate customerAccountDate;
	private Customer customerDetails;
	public float getCustomerBalance() {
		return customerBalance;
	}
	public void setCustomerBalance(float customerBalance) {
		this.customerBalance = customerBalance;
	}
	public int getCustomerAccountNo() {
		return customerAccountNo;
	}
	public void setCustomerAccountNo(int customerAccountNo) {
		this.customerAccountNo = customerAccountNo;
	}
	public LocalDate getCustomerAccountDate() {
		return customerAccountDate;
	}
	public void setCustomerAccountDate(LocalDate customerAccountDate) {
		this.customerAccountDate = customerAccountDate;
	}
	public Customer getCustomerDetails() {
		return customerDetails;
	}
	public void setCustomerDetails(Customer customerDetails) {
		this.customerDetails = customerDetails;
	}
	
	@Override
	public String toString() {
		return "Wallet [customerBalance=" + customerBalance + ", customerAccountNo=" + customerAccountNo
				+ ", customerAccountDate=" + customerAccountDate + ", customerDetails=" + customerDetails + "]";
	}


}

