package com.capgemini.paymentwallet.service;

import com.capgemini.paymentwallet.exception.AlreadyExistException;



public class PaymentWalletValidation {
	PaymentWalletService service = new PaymentWalletService();
	
	public boolean validateAadharNo(String aadharNo)
	{
		boolean bool= service.checkAadharNo(aadharNo);
				if(!bool)
				{
					try
					{
						throw new AlreadyExistException();
					}
					catch(AlreadyExistException e)
					{
						System.out.println("User Already Registered With This Aadhar Card..");
					}
					return false;
				}
					
		if(aadharNo.length()==12 && aadharNo.matches("[0-9]+"))
		{
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean validateCustomerName(String custName)
	{
		if(custName.matches("^[a-zA-Z]+(\\s[a-zA-Z]+)?$")) {
			return true;
		}
		return false;
	}
	
	public boolean validateGender(String gender)
	{
		if(gender.equalsIgnoreCase("Male")
				|| gender.equalsIgnoreCase("FeMale")
				|| gender.equalsIgnoreCase("M")
				|| gender.equalsIgnoreCase("F"))
		{
			return true;
		}
		return false;
	}
	
	
	
	public boolean validateUserName(String uName)
	{
		boolean b = service.checkUserName(uName);
		if(!b)
		{
			try
			{
				throw new AlreadyExistException();
			}
			catch(AlreadyExistException e)
			{
				System.out.println("User Name Already Exist");
			}
			return false;
		}
		
		if(uName.length()>=8 )
		{
			
			return true;
		}
		System.out.println("UserName Less than 8 characters");
		return false;
	}
	
	
	
	public boolean validateMobileNo(String custMobileNo)
	{
		boolean mbl= service.checkMobileNo(custMobileNo);
		if(!mbl)
		{
			try {
				throw new AlreadyExistException();
			}
			catch(AlreadyExistException e1)
			{
				System.out.println("Mobile Number already exist");
			}
			return false;
		}
		if(custMobileNo.length()==10 && custMobileNo.matches("[0-9]+"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateCustInitBal(float custInitBal)
	{
		if(custInitBal >=1000)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	
	public boolean validateUserPassword(String uPassword)
	{
		if(uPassword.length()>=5)
		{
			return true;
		}
		return false;
		
	}
	public boolean validateEmailId(String email)
	{
		if(email.matches("^[a-z]{1}[a-z 0-9_.]{1,}@gmail.com$"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
