package com.capgemini.paymentwallet.test;

import com.capgemini.paymentwallet.bean.Customer;

import junit.framework.TestCase;

public class CustomerTest extends TestCase {

	
	Customer customer = new Customer();
	
	public void testGetAadharNo() {
	
		customer.setAadharNo("123456789012");
		assertEquals("123456789012", customer.getAadharNo());
	}

	public void testGetCustomerName() {
		
		customer.setCustomerName("Nupur Vani");
		assertEquals("Nupur Vani", customer.getCustomerName());
	}

	public void testGetAge() {
		
		customer.setAge(21);
		assertEquals(21, customer.getAge());
	}

	public void testGetGender() {
		
		customer.setGender("Female");
		assertEquals("Female", customer.getGender());
	}

	public void testGetCustomerMobileNo() {
		
		customer.setCustomerMobileNo("7401797201");
		assertEquals("7401797201", customer.getCustomerMobileNo());
	}


	public void testGetCustomerEmail() {
		customer.setCustomerEmail("nupurvani@gmail.com");
		assertEquals("nupurvani@gmail.com", customer.getCustomerEmail());
	}

	public void testGetUserName() {
		
		customer.setUserName("nupurvani");
		assertEquals("nupurvani", customer.getUserName());
	}

	public void testGetUserPassword() {
		
		customer.setUserPassword("123456");
		assertEquals("123456", customer.getUserPassword());
	}

}