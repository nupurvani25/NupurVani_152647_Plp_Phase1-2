package com.capgemini.paymentwallet.test;


	import java.time.LocalDate;

	import com.capgemini.paymentwallet.bean.Customer;
	import com.capgemini.paymentwallet.bean.Wallet;

	import junit.framework.TestCase;

	public class WalletTest extends TestCase {
		
		Wallet w = new Wallet();
		public void testGetCustBal() {

			w.setCustomerBalance(50000.0f);
			assertEquals(50000.0f, w.getCustomerBalance());
		}

		public void testGetCustAccNo() {

			w.setCustomerAccountNo(123456);
			assertEquals(123456, w.getCustomerAccountNo());
		}

		public void testGetCustAccDate() {
			
			w.setCustomerAccountDate(LocalDate.now());
			assertEquals(LocalDate.now(), w.getCustomerAccountDate());
			
		}

		public void testGetCustomerDetails() {

			Customer c = new Customer();
			w.setCustomerDetails(c);
			assertEquals(c, w.getCustomerDetails());
		}

	}

