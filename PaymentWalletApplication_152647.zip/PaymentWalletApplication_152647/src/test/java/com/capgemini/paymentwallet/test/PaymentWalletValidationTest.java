package com.capgemini.paymentwallet.test;

import com.capgemini.paymentwallet.service.PaymentWalletValidation;

import junit.framework.Assert;
import junit.framework.TestCase;

public class PaymentWalletValidationTest extends TestCase {

	PaymentWalletValidation validate = new PaymentWalletValidation();
	
	public void testValidateAadharNo() {
		
		Assert.assertEquals(true, validate.validateAadharNo("012345678978"));
		Assert.assertEquals(false, validate.validateAadharNo("12345"));
		
	}

	public void testValidateCustomerName() {
		
		Assert.assertEquals(true, validate.validateCustomerName("Nupur Vani"));
		Assert.assertEquals(false, validate.validateCustomerName("nups25"));
		
	}

	public void testValidateGender() {
		
		Assert.assertEquals(true, validate.validateGender("Male"));
		Assert.assertEquals(true, validate.validateGender("Female"));
		Assert.assertEquals(true, validate.validateGender("F"));
		Assert.assertEquals(true, validate.validateGender("M"));
		Assert.assertEquals(false, validate.validateGender("Hello"));
		
	}

	public void testValidateUserName() {
	
		Assert.assertEquals(true, validate.validateUserName("nupurvani"));
		Assert.assertEquals(false, validate.validateUserName("nupur"));
		
		
	}

	public void testValidateMobileNo() {
		
		Assert.assertEquals(true, validate.validateMobileNo("7401797201"));
		Assert.assertEquals(false, validate.validateMobileNo("a123dfg"));
		
	}

	public void testValidateCustInitBal() {
		
		Assert.assertEquals(true , validate.validateCustInitBal(20000));
		Assert.assertEquals(false, validate.validateCustInitBal(500));
	
	}

	public void testValidateUserPassword() {
		
		Assert.assertEquals(true , validate.validateUserPassword("123456"));
		Assert.assertEquals(false, validate.validateUserPassword("123"));
	
	}

	public void testValidateEmailId() {
		
		Assert.assertEquals(true, validate.validateEmailId("nupurvani@gmail.com"));
		Assert.assertEquals(false, validate.validateEmailId("abc"));
	
	}

}